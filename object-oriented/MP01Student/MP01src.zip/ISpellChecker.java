public interface ISpellChecker {
    void check();
}
